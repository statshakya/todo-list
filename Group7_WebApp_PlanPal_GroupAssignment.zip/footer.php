<!-- footer.php -->
<footer class="footer text-center mt-auto py-3 style="background:#d6a4f0; width: 100%;">
  <div class="container">
    <span class="text-muted">© <?= date('Y') ?> PlanPal. All rights reserved.</span>
  </div>
</footer>

